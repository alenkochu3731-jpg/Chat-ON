import express from "express";
import dotenv from "dotenv";
import OpenAI from "openai";

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

if (!process.env.OPENAI_API_KEY) {
  console.warn("OPENAI_API_KEY is missing. Add it to .env before using the AI.");
}

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

app.use(express.json({ limit: "1mb" }));
app.use(express.static("."));

app.post("/api/chat", async (req, res) => {
  try {
    const message = String(req.body?.message || "").trim();

    if (!message) {
      return res.status(400).json({ error: "Message is empty." });
    }

    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({
        error: "OPENAI_API_KEY is not configured on the server."
      });
    }

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.6",
      instructions:
        "You are Chat On, a friendly and helpful AI assistant. " +
        "If the user writes Malayalam, reply naturally in Malayalam. " +
        "If the user writes English, reply in English. " +
        "You can also understand Manglish Malayalam. " +
        "Keep answers clear and useful.",
      input: message
    });

    res.json({ reply: response.output_text });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error: "AI response ലഭിച്ചില്ല. API key/model/server പരിശോധിക്കുക."
    });
  }
});

app.listen(port, () => {
  console.log(`Chat On running at http://localhost:${port}`);
});
